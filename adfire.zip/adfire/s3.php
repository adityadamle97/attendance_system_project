<?php
session_start();
$u=$_SESSION['usn'];
echo $u;
?>
