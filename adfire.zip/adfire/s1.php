<html>
<title>Session test 1</title>
<form method="post" action="s2.php">
Enter your name<input type="text" name="s"><br>
<input type="submit" value="submit">
</form>
</html>
