<?php
echo pg_version();
?>
