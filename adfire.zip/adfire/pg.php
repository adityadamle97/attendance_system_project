<?php
$db=pg_connect("localhost","aditya1927","aditya1927","onlyubuntu17");
if($db)
echo "conn";
else
echo "fail";
?>
