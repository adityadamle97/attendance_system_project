<html>
<title>Admin Profile</title>
<body bgcolor="yellow">
<form method="post" action="aselect.php">
<center><font size="7" face="helvetica" color="blue">Welcome to Admin page</font></center>
<h3>Please select the operation you would like to perform</h3>
<a href="aselect.php"><input type="button" value="View the tables"></a><br>
<a href="aupdate.php"><input type="button" value="Update the tables"></a><br>
<a href="adelete.php"><input type="button" value="Delete from the tables"></a><br>
<center><input type="submit" value="Submit"></center>
<html>
